#ifndef NP_WEATHER_BACKGROUND_ASSETS_H
#define NP_WEATHER_BACKGROUND_ASSETS_H

#include <stdbool.h>

#include "weather_condition.h"

#ifdef __cplusplus
extern "C" {
#endif

#define NP_WEATHER_BACKGROUND_WIDTH  500
#define NP_WEATHER_BACKGROUND_HEIGHT 462

/* Legacy embedded source hook. Production Home backgrounds now load from SD. */
const void *np_weather_background_asset_source(bool is_day, weather_condition_t condition);

/* Basenames on the SD card. The loader prefixes BSP_SD_MOUNT_POINT and
 * /np2/weather/. Keeping the catalog here makes the 20-file mapping unique. */
const char *np_weather_background_asset_file_name(bool is_day,
                                                   weather_condition_t condition);

#ifdef __cplusplus
}
#endif

#endif /* NP_WEATHER_BACKGROUND_ASSETS_H */
