# Backgrounds meteorológicos da Home

Cada asset deve ser exportado em **RGB565 bruto**,
sem cabeçalho, com **500 x 462 px** (462000 bytes). Esse é exatamente o tamanho
externo do `weather_card`; o card não possui padding implícito e a imagem não é
redimensionada em tempo de execução.

O arquivo no cartão permanece compacto, com 1000 bytes por linha. Ao carregá-lo,
o firmware o posiciona em um slot PSRAM com stride de 1024 bytes exigido pelo
renderer LVGL desta placa. São somente 24 bytes de padding limpos por linha:
não há escala, decodificação nem conversão de cor durante o desenho.

Mantenha os 20 arquivos-fonte em `firmware/main/ui/assets/weather/` e copie-os
para o cartão microSD em `np2/weather/` com
`tools/copy_weather_assets_to_sd.ps1`. O firmware monta o cartão em `/sdcard`
e os lê de `/sdcard/np2/weather/`; eles **não** são embutidos na aplicação ou
na partição flash interna.

```
np_bg_day_clear.bin                 np_bg_night_clear.bin
np_bg_day_partly_cloudy.bin         np_bg_night_partly_cloudy.bin
np_bg_day_fog.bin                   np_bg_night_fog.bin
np_bg_day_drizzle.bin               np_bg_night_drizzle.bin
np_bg_day_rain.bin                  np_bg_night_rain.bin
np_bg_day_snow.bin                  np_bg_night_snow.bin
np_bg_day_rain_showers.bin          np_bg_night_rain_showers.bin
np_bg_day_snow_showers.bin          np_bg_night_snow_showers.bin
np_bg_day_thunderstorm.bin          np_bg_night_thunderstorm.bin
np_bg_day_variable.bin              np_bg_night_variable.bin
```

Sem cartão, sem os arquivos ou com um arquivo de tamanho inválido, a Home usa
o card escuro neutro. Não há imagem de substituição, escala ou conversão em
runtime.
