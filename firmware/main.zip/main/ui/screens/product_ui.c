#include "product_ui.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "app_state.h"
#include "diagnostic_ui.h"
#include "esp_check.h"
#include "esp_log.h"
#include "offline_value_format.h"
#include "np_screens.h"
#include "weather_condition.h"

#define UI_REFRESH_PERIOD_MS 250U
#define BOOT_MINIMUM_MS 1200U
#define BOOT_MAXIMUM_MS 6000U

typedef struct {
    lv_display_t *display;
    lv_indev_t *touch_indev;
    np_boot_view_t boot;
    np_home_view_t home;
    lv_timer_t *refresh_timer;
    uint32_t started_at_tick;
    uint32_t rendered_revision;
    bool home_visible;
} product_ui_state_t;

static product_ui_state_t s_ui;
static const char *const TAG = "product_ui";

static np_data_state_t data_state(bool available, bool stale)
{
    if (!available) return NP_DATA_UNAVAILABLE;
    return stale ? NP_DATA_STALE : NP_DATA_LIVE;
}

static bool projection_local_time(const app_ui_projection_t *projection, struct tm *local)
{
    if (projection == NULL || local == NULL || !projection->time_trusted ||
        projection->current_unix_s == 0U) {
        return false;
    }
    const time_t now = (time_t)projection->current_unix_s;
    return localtime_r(&now, local) != NULL;
}

static void format_age(uint32_t age_s, char *out, size_t out_size)
{
    if (out == NULL || out_size == 0U) return;
    if (age_s == UINT32_MAX) {
        (void)snprintf(out, out_size, "horário indisponível");
    } else if (age_s < 60U) {
        (void)snprintf(out, out_size, "atualizado agora");
    } else if (age_s < 3600U) {
        (void)snprintf(out, out_size, "há %lu min", (unsigned long)(age_s / 60U));
    } else {
        (void)snprintf(out, out_size, "há %lu h", (unsigned long)(age_s / 3600U));
    }
}

static void format_btc_price_parts(uint32_t cents, char *whole_out, size_t whole_out_size,
                                   char *fraction_out, size_t fraction_out_size)
{
    const unsigned long whole = (unsigned long)(cents / 100U);
    const unsigned long fraction = (unsigned long)(cents % 100U);
    if (whole >= 1000000UL) {
        (void)snprintf(whole_out, whole_out_size, "%lu.%03lu.%03lu",
                       whole / 1000000UL, (whole / 1000UL) % 1000UL, whole % 1000UL);
    } else if (whole >= 1000UL) {
        (void)snprintf(whole_out, whole_out_size, "%lu.%03lu", whole / 1000UL, whole % 1000UL);
    } else {
        (void)snprintf(whole_out, whole_out_size, "%lu", whole);
    }
    (void)snprintf(fraction_out, fraction_out_size, ",%02lu", fraction);
}

static void update_clock(const app_ui_projection_t *projection)
{
    struct tm local = {0};
    if (!projection_local_time(projection, &local)) {
        np_clock_set(&s_ui.home.clock, "--:--");
        np_set_text(s_ui.home.date, "Aguardando sincronização de data e hora");
        return;
    }
    static const char *const weekdays[] = {
        "Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira",
        "Quinta-feira", "Sexta-feira", "Sábado",
    };
    static const char *const months[] = {
        "janeiro", "fevereiro", "março", "abril", "maio", "junho",
        "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
    };
    char clock[6] = {0};
    char date[48] = {0};
    (void)snprintf(clock, sizeof(clock), "%02d:%02d", local.tm_hour, local.tm_min);
    (void)snprintf(date, sizeof(date), "%s, %d de %s", weekdays[local.tm_wday],
                   local.tm_mday, months[local.tm_mon]);
    np_clock_set(&s_ui.home.clock, clock);
    np_set_text(s_ui.home.date, date);
}

static void update_weather(const app_ui_projection_t *projection)
{
    const offline_weather_data_t *weather = &projection->offline_data.weather;
    np_home_set_weather_background_source(&s_ui.home, projection->weather_assets.source);
    np_status_pill_set(&s_ui.home.weather_status,
                       data_state(weather->available, weather->stale));
    if (!weather->available) {
        np_set_text(s_ui.home.weather_temperature, "--°");
        np_set_text(s_ui.home.weather_place, "Brasília");
        np_set_text(s_ui.home.weather_summary, "Dados de clima indisponíveis");
        np_set_text(s_ui.home.weather_humidity, "--");
        return;
    }
    char temperature[16] = {0};
    char display_temperature[20] = {0};
    char humidity[12] = {0};
    if (!offline_format_temperature(weather->temperature_deci_c,
                                    temperature, sizeof(temperature))) {
        (void)snprintf(temperature, sizeof(temperature), "--");
    }
    char *separator = strchr(temperature, '.');
    if (separator != NULL) *separator = ',';
    (void)snprintf(display_temperature, sizeof(display_temperature), "%s°", temperature);
    (void)snprintf(humidity, sizeof(humidity), "%u%%",
                   (unsigned int)weather->relative_humidity_percent);
    np_set_text(s_ui.home.weather_temperature, display_temperature);
    np_set_text(s_ui.home.weather_place, "Brasília");
    np_set_text(s_ui.home.weather_summary,
                weather_condition_summary(weather_condition_from_code(weather->weather_code)));
    np_set_text(s_ui.home.weather_humidity, humidity);
}

static void update_market(const app_ui_projection_t *projection)
{
    const offline_market_data_t *market = &projection->offline_data.market;
    np_status_pill_set(&s_ui.home.btc_status,
                       data_state(market->available, market->stale));
    if (!market->available) {
        np_set_text(s_ui.home.btc_price_prefix, "US$");
        np_set_text(s_ui.home.btc_price_whole, "--");
        np_set_text(s_ui.home.btc_price_fraction, ",--");
        np_set_text(s_ui.home.btc_change_icon, NP_ICON_RISE);
        np_set_text(s_ui.home.btc_change, "--");
        np_set_text_color(s_ui.home.btc_change_icon, np_c_text_3());
        np_set_text_color(s_ui.home.btc_change, np_c_text_3());
        np_set_text(s_ui.home.btc_age, "Aguardando primeira cotação válida");
        return;
    }
    char price_whole[20] = {0};
    char price_fraction[8] = {0};
    char change_value[16] = {0};
    char change[28] = {0};
    char age[32] = {0};
    format_btc_price_parts(market->bitcoin_usd_cents, price_whole, sizeof(price_whole),
                           price_fraction, sizeof(price_fraction));
    if (!offline_format_market_change(market->change_24h_basis_points,
                                      change_value, sizeof(change_value))) {
        (void)snprintf(change_value, sizeof(change_value), "--");
    }
    char *separator = strchr(change_value, '.');
    if (separator != NULL) *separator = ',';
    (void)snprintf(change, sizeof(change), "%s%s%%",
                   market->change_24h_basis_points > 0 ? "+" : "", change_value);
    format_age(projection->market_age_s, age, sizeof(age));
    const lv_color_t change_color = market->change_24h_basis_points >= 0 ? np_c_positive()
                                                                          : np_c_negative();
    np_set_text(s_ui.home.btc_price_prefix, "US$");
    np_set_text(s_ui.home.btc_price_whole, price_whole);
    np_set_text(s_ui.home.btc_price_fraction, price_fraction);
    np_set_text(s_ui.home.btc_change_icon,
                market->change_24h_basis_points >= 0 ? NP_ICON_RISE : NP_ICON_FALL);
    np_set_text(s_ui.home.btc_change, change);
    np_set_text_color(s_ui.home.btc_change_icon, change_color);
    np_set_text_color(s_ui.home.btc_change, change_color);
    np_set_text(s_ui.home.btc_age, age);
}

static void update_exchange(const app_ui_projection_t *projection)
{
    const offline_exchange_data_t *const exchange = &projection->offline_data.exchange;
    if (!exchange->available) {
        np_set_text(s_ui.home.exchange_usd_brl, "Indisponível");
        np_set_text_color(s_ui.home.exchange_usd_brl, np_c_text_3());
        return;
    }
    const unsigned long whole = (unsigned long)(exchange->usd_brl_ten_thousandths / 10000U);
    const unsigned long fraction =
        (unsigned long)(exchange->usd_brl_ten_thousandths % 10000U);
    char value[24] = {0};
    (void)snprintf(value, sizeof(value), "R$ %lu,%04lu", whole, fraction);
    np_set_text(s_ui.home.exchange_usd_brl, value);
    np_set_text_color(s_ui.home.exchange_usd_brl,
                      exchange->stale ? np_c_text_3() : np_c_text());
}

static uint8_t boot_progress(const app_ui_projection_t *projection)
{
    uint8_t stage = 1U;
    if (projection->storage.ready) stage = 2U;
    if (projection->network.state >= APP_NETWORK_STATE_LINK_UP) stage = 3U;
    if (projection->time_trusted) stage = 4U;
    if (projection->offline_data.weather.available ||
        projection->offline_data.market.available) stage = 5U;
    return stage;
}

static void update_boot(const app_ui_projection_t *projection)
{
    const uint8_t stage = boot_progress(projection);
    static const char *const status[] = {
        "Preparando o display", "Verificando o armazenamento",
        "Procurando redes Wi-Fi", "Atualizando data e hora",
        "Carregando os dados do painel", "Tudo pronto",
    };
    np_segbar_set(&s_ui.boot.progress, stage, np_c_accent());
    np_set_text(s_ui.boot.status, status[stage]);
    if (stage < 3U) {
        np_set_text(s_ui.boot.detail, "A inicialização continua mesmo sem internet.");
    } else if (!projection->network.online) {
        np_set_text(s_ui.boot.detail, "O painel abrirá com os últimos dados salvos.");
    } else {
        np_set_text(s_ui.boot.detail, "Conexão disponível; concluindo a inicialização.");
    }
}

static void update_home(const app_ui_projection_t *projection)
{
    update_clock(projection);
    update_weather(projection);
    update_exchange(projection);
    update_market(projection);
    np_header_set_connections(&s_ui.home.header, projection->network.online,
                              false, projection->network.state == APP_NETWORK_STATE_FAILED ||
                                         projection->storage.last_result != ESP_OK);
}

static void show_home(void)
{
    if (s_ui.home_visible) return;
    lv_obj_add_flag(s_ui.boot.root, LV_OBJ_FLAG_HIDDEN);
    lv_obj_remove_flag(s_ui.home.root, LV_OBJ_FLAG_HIDDEN);
    s_ui.home_visible = true;
    ESP_LOGI(TAG, "Boot transition complete; Home visible");
}

static void refresh_timer_cb(lv_timer_t *timer)
{
    (void)timer;
    app_ui_projection_t projection = {0};
    app_state_get_ui_projection(&projection);
    /* A app_loop já agrupa mudanças e incrementa revision uma vez por
     * projeção. Não toque em widgets quando nenhum dado mudou. */
    if (projection.revision != s_ui.rendered_revision) {
        update_boot(&projection);
        update_home(&projection);
        s_ui.rendered_revision = projection.revision;
    }
    const uint32_t elapsed = lv_tick_elaps(s_ui.started_at_tick);
    if (elapsed >= BOOT_MINIMUM_MS && projection.ready &&
        (projection.time_trusted || elapsed >= BOOT_MAXIMUM_MS)) {
        show_home();
    } else if (elapsed >= BOOT_MAXIMUM_MS) {
        show_home();
    }
}

static void diagnostics_button_event_cb(lv_event_t *event)
{
    if (lv_event_get_code(event) != LV_EVENT_CLICKED) return;
    if (s_ui.refresh_timer != NULL) lv_timer_delete(s_ui.refresh_timer);
    lv_display_t *display = s_ui.display;
    lv_indev_t *touch_indev = s_ui.touch_indev;
    s_ui = (product_ui_state_t){0};
    lv_obj_clean(lv_screen_active());
    (void)diagnostic_ui_create(display, touch_indev);
}

esp_err_t product_ui_create(lv_display_t *display, lv_indev_t *touch_indev)
{
    ESP_RETURN_ON_FALSE(display != NULL && touch_indev != NULL, ESP_ERR_INVALID_ARG,
                        "product_ui", "Display or touch handle missing");
    s_ui = (product_ui_state_t){
        .display = display,
        .touch_indev = touch_indev,
        .started_at_tick = lv_tick_get(),
        .rendered_revision = UINT32_MAX,
    };
    lv_obj_t *screen = lv_screen_active();
    lv_obj_clean(screen);
    lv_obj_remove_style_all(screen);
    s_ui.boot = np_boot_build(screen);
    s_ui.home = np_home_build(screen);
    lv_obj_add_flag(s_ui.home.root, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_event_cb(s_ui.home.header.settings_button, diagnostics_button_event_cb,
                        LV_EVENT_CLICKED, NULL);
    s_ui.refresh_timer = lv_timer_create(refresh_timer_cb, UI_REFRESH_PERIOD_MS, NULL);
    ESP_RETURN_ON_FALSE(s_ui.refresh_timer != NULL, ESP_ERR_NO_MEM,
                        "product_ui", "UI refresh timer allocation failed");
    refresh_timer_cb(s_ui.refresh_timer);
    return ESP_OK;
}
