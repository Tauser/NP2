/*
 * NovaPanel v5 -- modelos de tela (camada 4).
 *
 * Cada tela e um arquivo. As telas de produto devolvem os handles que o
 * controlador precisa atualizar; o mesmo codigo e usado no simulador e
 * compilado diretamente pelo firmware.
 *
 * Quatro arquetipos cobrem as treze telas (UI-LAYOUT-SYSTEM.md SS3.4):
 *
 *   Hero   -- 1 foco + apoio           Home, Market, Weather, Timer
 *   Lista  -- N linhas recicladas      Agenda, Alarms, Notifications
 *   Grade  -- tiles de acao            Devices, Settings
 *   Fluxo  -- full-bleed, um passo     Boot, Setup, Sheets
 *
 * As telas marcadas ASPIRACIONAL abaixo nao existem no produto: nao ha
 * servico, provider nem campo de estado que as alimente. Elas vivem aqui
 * como exploracao de layout e NAO devem virar firmware antes de existir
 * fonte de dado aprovada -- desenhar interface para dado inexistente e
 * proibido por docs/UX_LAYOUT_REDESIGN.md SS2.
 */

#ifndef NP_SCREENS_H
#define NP_SCREENS_H

#include "np_components.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    lv_obj_t *root;
    np_segbar_t progress;
    lv_obj_t *status;
    lv_obj_t *detail;
} np_boot_view_t;

typedef struct {
    lv_obj_t *root;
    np_header_t header;
    lv_obj_t *weather_card;
    lv_obj_t *weather_background;
    np_clock_t clock;
    lv_obj_t *date;
    lv_obj_t *weather_temperature;
    lv_obj_t *weather_place;
    lv_obj_t *weather_summary;
    lv_obj_t *weather_humidity;
    np_pill_t weather_status;
    lv_obj_t *exchange_usd_brl;
    lv_obj_t *btc_price_prefix;
    lv_obj_t *btc_price_whole;
    lv_obj_t *btc_price_fraction;
    lv_obj_t *btc_change_icon;
    lv_obj_t *btc_change;
    lv_obj_t *btc_age;
    np_pill_t btc_status;
} np_home_view_t;

np_boot_view_t np_boot_build(lv_obj_t *parent);
np_home_view_t np_home_build(lv_obj_t *parent);

/* Fallback temporário até sunrise/sunset entrar no contrato de clima. */
bool np_home_is_day(uint8_t hour);
const void *np_home_weather_background_source(uint8_t hour, uint16_t weather_code);
void np_home_set_weather_background_source(np_home_view_t *view, const void *source);
void np_home_set_weather_visual(np_home_view_t *view, uint8_t hour, uint16_t weather_code);

/* Wrappers para o catalogo/simulador. */
lv_obj_t *np_boot_create(lv_obj_t *parent);
lv_obj_t *np_home_create(lv_obj_t *parent);
lv_obj_t *np_market_create(lv_obj_t *parent);        /* Hero  */
lv_obj_t *np_setup_create(lv_obj_t *parent);         /* Fluxo */

/* ---- ASPIRACIONAL: sem fonte de dado hoje ---- */
lv_obj_t *np_weather_create(lv_obj_t *parent);       /* Hero  -- so temp/resumo existem */
lv_obj_t *np_timer_create(lv_obj_t *parent);         /* Hero  */
lv_obj_t *np_agenda_create(lv_obj_t *parent);        /* Lista -- ROADMAP Fase 8 */
lv_obj_t *np_alarms_create(lv_obj_t *parent);        /* Lista */
lv_obj_t *np_notifications_create(lv_obj_t *parent); /* Lista */
lv_obj_t *np_devices_create(lv_obj_t *parent);       /* Grade -- automacao, fase futura */
lv_obj_t *np_settings_create(lv_obj_t *parent);      /* Grade */
lv_obj_t *np_sheets_create(lv_obj_t *parent);        /* Fluxo -- painel lateral sobreposto */

/* Catalogo para o harness de mockup iterar. */
typedef struct {
    const char *id;
    const char *title;
    const char *archetype;
    lv_obj_t *(*create)(lv_obj_t *parent);
} np_screen_entry_t;

const np_screen_entry_t *np_screen_catalog(void);
int np_screen_catalog_count(void);

#ifdef __cplusplus
}
#endif

#endif /* NP_SCREENS_H */
