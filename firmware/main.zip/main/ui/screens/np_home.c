/*
 * Home ("Agora").
 *
 * A cena mantém o fundo neutro. A leitura ambiental vive apenas no card de
 * clima: imagem RGB565 inteira, overlay escuro e, por cima, conteúdo estável.
 * A troca de condição muda somente a source da imagem já criada.
 */

#include "np_components.h"
#include "np_screens.h"
#include "np_styles.h"
#include "esp_log.h"
#include "np_tokens.h"
#include "weather_condition.h"
#include "../assets/np_weather_background_assets.h"

#define NP_HOME_WEATHER_CARD_X 24
#define NP_HOME_WEATHER_CARD_Y 88
#define NP_HOME_WEATHER_CARD_W NP_WEATHER_BACKGROUND_WIDTH
#define NP_HOME_WEATHER_CARD_H NP_WEATHER_BACKGROUND_HEIGHT

/*
 * O overlay precisa ser forte o bastante para preservar a leitura dos textos
 * secundários (np_c_text_2 / np_c_text_3) sobre qualquer condição climática.
 *
 * DIA: fundo naturalmente mais claro -> overlay um pouco mais forte.
 * NOITE: mantém a arte visível, mas ainda protege os textos cinza.
 *
 * lv_opa_t usa 0..255. 148 ~= 58% e 140 ~= 55%.
 */
#define NP_HOME_WEATHER_OVERLAY_OPA_DAY   ((lv_opa_t)148)
#define NP_HOME_WEATHER_OVERLAY_OPA_NIGHT ((lv_opa_t)140)


/*
 * O componente np_clock pode aplicar uma cor de destaque ao separador ":".
 * Na Home queremos o relógio monocromático. Como a Home não deve depender
 * da estrutura interna de np_clock_t, recolorimos somente os objetos criados
 * pela chamada de np_clock(), imediatamente após sua criação.
 */
static void np_home_force_text_color_recursive(lv_obj_t *obj, lv_color_t color)
{
    if (obj == NULL) return;

    if (lv_obj_check_type(obj, &lv_label_class)) {
        lv_obj_set_style_text_color(obj, color, LV_PART_MAIN);
    }

    const uint32_t child_count = lv_obj_get_child_count(obj);
    for (uint32_t i = 0; i < child_count; ++i) {
        np_home_force_text_color_recursive(lv_obj_get_child(obj, (int32_t)i), color);
    }
}

static void np_home_clock_force_single_color(lv_obj_t *parent,
                                              uint32_t first_new_child,
                                              lv_color_t color)
{
    if (parent == NULL) return;

    const uint32_t child_count = lv_obj_get_child_count(parent);
    for (uint32_t i = first_new_child; i < child_count; ++i) {
        np_home_force_text_color_recursive(lv_obj_get_child(parent, (int32_t)i), color);
    }
}

static const char *const TAG = "np_home";

bool np_home_is_day(uint8_t hour)
{
    return weather_condition_is_day(hour);
}

static lv_obj_t *np_home_weather_overlay(const np_home_view_t *view)
{
    if (view == NULL || view->weather_card == NULL) return NULL;

    /*
     * Ordem de criação do card:
     *   child 0 = weather_background
     *   child 1 = overlay
     *
     * O overlay é criado antes de relógio, data e demais widgets.
     */
    return lv_obj_get_child(view->weather_card, 1);
}

static lv_opa_t np_home_weather_overlay_opacity(uint8_t hour)
{
    return np_home_is_day(hour)
               ? NP_HOME_WEATHER_OVERLAY_OPA_DAY
               : NP_HOME_WEATHER_OVERLAY_OPA_NIGHT;
}

static void np_home_set_weather_overlay_opacity(np_home_view_t *view, uint8_t hour)
{
    if (view == NULL || hour > 23U) return;

    lv_obj_t *const overlay = np_home_weather_overlay(view);
    if (overlay == NULL) return;

    const lv_opa_t wanted = np_home_weather_overlay_opacity(hour);
    const lv_opa_t current = lv_obj_get_style_bg_opa(overlay, LV_PART_MAIN);

    /*
     * Evita invalidar o overlay quando a projeção DIA/NOITE não mudou.
     * Na prática, a opacidade só muda na transição entre os períodos.
     */
    if (current == wanted) return;

    lv_obj_set_style_bg_opa(overlay, wanted, LV_PART_MAIN);
}

const void *np_home_weather_background_source(uint8_t hour, uint16_t weather_code)
{
    if (hour > 23U) return NULL;
    return np_weather_background_asset_source(np_home_is_day(hour),
                                              weather_condition_from_code(weather_code));
}

void np_home_set_weather_background_source(np_home_view_t *view, const void *source)
{
    if (view == NULL || view->weather_background == NULL) return;
    /* A imagem tem raio próprio. Não use clip_corner no container inteiro:
     * no renderer RGB parcial isso cria uma layer temporária do tamanho do
     * card e pode atrasar a task LVGL. */
    if (source == NULL) {
        np_image_set_source(view->weather_background, NULL);
        return;
    }

    /* A projeção também muda com o relógio. Sem troca de source ou de
     * visibilidade, não há razão para repintar os 500 x 462 px do card. */
    if (lv_image_get_src(view->weather_background) == source &&
        !lv_obj_has_flag(view->weather_background, LV_OBJ_FLAG_HIDDEN)) {
        return;
    }

    const lv_image_dsc_t *const image = source;
    if (image->header.magic != LV_IMAGE_HEADER_MAGIC ||
        image->header.cf != LV_COLOR_FORMAT_RGB565 ||
        image->header.w != NP_HOME_WEATHER_CARD_W ||
        image->header.h != NP_HOME_WEATHER_CARD_H) {
        ESP_LOGE(TAG, "weather background rejected: magic=%u cf=%u %lux%lu",
                 (unsigned int)image->header.magic, (unsigned int)image->header.cf,
                 (unsigned long)image->header.w, (unsigned long)image->header.h);
        np_image_set_source(view->weather_background, NULL);
        return;
    }

    /* Este é o primeiro filho visual do card. Reafirmar a ordem evita que
     * uma atualização de conteúdo o deixe acima do overlay ou de um widget. */
    lv_obj_move_background(view->weather_background);
    lv_obj_set_style_opa(view->weather_background, LV_OPA_COVER, 0);
    np_image_set_source(view->weather_background, source);
    lv_obj_invalidate(view->weather_card);
    ESP_LOGI(TAG, "weather background applied: %lux%lu RGB565", (unsigned long)image->header.w,
             (unsigned long)image->header.h);
}

void np_home_set_weather_visual(np_home_view_t *view, uint8_t hour, uint16_t weather_code)
{
    if (view == NULL || hour > 23U) return;

    np_home_set_weather_background_source(view,
                                          np_home_weather_background_source(hour, weather_code));

    /*
     * A mesma atualização que resolve DIA/NOITE para o asset também ajusta
     * a proteção de contraste do conteúdo do card.
     */
    np_home_set_weather_overlay_opacity(view, hour);
}

np_home_view_t np_home_build(lv_obj_t *parent)
{
    np_home_view_t view = {0};
    view.root = np_scene(parent);
    view.header = np_header(view.root);

    /* Background e overlay são os primeiros filhos. Ambos têm o mesmo raio do
     * card, portanto nunca escapam pelos seus cantos sem exigir clipping do
     * container inteiro. */
    view.weather_card = np_glass(view.root, NP_HOME_WEATHER_CARD_X, NP_HOME_WEATHER_CARD_Y,
                                 NP_HOME_WEATHER_CARD_W, NP_HOME_WEATHER_CARD_H);
    view.weather_background = np_image(view.weather_card, 0, 0,
                                       NP_HOME_WEATHER_CARD_W, NP_HOME_WEATHER_CARD_H);
    lv_obj_set_style_radius(view.weather_background, NP_RADIUS_SURFACE, 0);
    lv_obj_set_style_opa(view.weather_background, LV_OPA_COVER, 0);
    np_fill(view.weather_card, 0, 0, NP_HOME_WEATHER_CARD_W, NP_HOME_WEATHER_CARD_H,
            np_c_bg(), NP_HOME_WEATHER_OVERLAY_OPA_DAY, NP_RADIUS_SURFACE);

    const uint32_t clock_first_child = lv_obj_get_child_count(view.weather_card);
    view.clock = np_clock(view.weather_card, NP_SP_24, NP_SP_16, NP_FONT_HERO, np_c_text());
    np_home_clock_force_single_color(view.weather_card, clock_first_child, np_c_text());

    view.date = np_label(view.weather_card, "Aguardando sincronização de data e hora", NP_FONT_MD,
                         np_c_text_2(), NP_SP_24, 128, 452, LV_TEXT_ALIGN_LEFT);
    np_hline(view.weather_card, NP_SP_24, 174, 452);

    np_label(view.weather_card, "CLIMA AGORA", NP_FONT_SM, np_c_text_2(),
             NP_SP_24, 190, 220, LV_TEXT_ALIGN_LEFT);
    view.weather_status = np_status_pill(view.weather_card, 376, 190, NP_DATA_UNAVAILABLE);
    view.weather_temperature = np_label(view.weather_card, "--°", NP_FONT_BRAND, np_c_text(),
                                        NP_SP_24, 216, 160, LV_TEXT_ALIGN_LEFT);
    view.weather_place = np_label(view.weather_card, "Brasília", NP_FONT_MD, np_c_text(),
                                  190, 226, 262, LV_TEXT_ALIGN_LEFT);
    view.weather_summary = np_label(view.weather_card, "Dados de clima indisponíveis", NP_FONT_SM,
                                    np_c_text_2(), 190, 256, 262, LV_TEXT_ALIGN_LEFT);
    np_hline(view.weather_card, NP_SP_24, 300, 452);

    np_metric(view.weather_card, NP_SP_24, 318, 102, "Vento", "--", NP_FONT_MD);
    np_metric_t humidity = np_metric(view.weather_card, 134, 318, 102, "Umidade", "--", NP_FONT_MD);
    view.weather_humidity = humidity.value;
    np_metric(view.weather_card, 244, 318, 102, "Sensação", "--", NP_FONT_MD);
    np_metric(view.weather_card, 354, 318, 98, "UV", "--", NP_FONT_MD);
    np_hline(view.weather_card, NP_SP_24, 382, 452);

    np_metric_t exchange = np_metric(view.weather_card, NP_SP_24, 398, 206, "Dólar · USD/BRL",
                                      "Indisponível", NP_FONT_SM);
    view.exchange_usd_brl = exchange.value;
    np_metric(view.weather_card, 252, 398, 200, "Ibovespa", "Indisponível", NP_FONT_SM);

    /* BTC conserva o card e os handles de atualização existentes. */
    lv_obj_t *card = np_glass(view.root, 540, 88, 460, 462);
    const int32_t card_pad = NP_SP_24;
    const int32_t card_inner_w = 460 - 2 * card_pad;
    np_label(card, "Bitcoin", NP_FONT_MD, np_c_text(), card_pad, card_pad, 150, LV_TEXT_ALIGN_LEFT);
    np_label(card, "BTC/USD", NP_FONT_SM, np_c_text_3(), card_pad + 106, card_pad + 4,
             100, LV_TEXT_ALIGN_LEFT);
    view.btc_status = np_status_pill(card, 336, card_pad + 2, NP_DATA_UNAVAILABLE);
    /*
     * Preço principal: sem centavos. "US$" fica discreto e o inteiro usa
     * NP_FONT_HERO para ganhar protagonismo sem disputar com o relógio.
     */
    view.btc_price_prefix = np_label(card, "US$", NP_FONT_SM, np_c_text_3(),
                                     card_pad, card_pad + 64, 42, LV_TEXT_ALIGN_LEFT);

    view.btc_price_whole = np_label(card, "--", NP_FONT_BRAND, np_c_text(),
                                    card_pad + 46, card_pad + 42,
                                    card_inner_w - 46, LV_TEXT_ALIGN_LEFT);

    /*
     * Mantém o handle por compatibilidade com o controlador existente,
     * mas o ",00" deixa de fazer parte da interface.
     */
    view.btc_price_fraction = np_label(card, "", NP_FONT_SM, np_c_text_2(),
                                       0, 0, 1, LV_TEXT_ALIGN_LEFT);
    lv_obj_add_flag(view.btc_price_fraction, LV_OBJ_FLAG_HIDDEN);

    /*
     * Atualização da cotação fica junto ao cabeçalho, abaixo do status.
     * Exemplo em runtime: "há 2 min".
     */
    view.btc_age = np_label(card, "Aguardando atualização", NP_FONT_SM, np_c_text_3(),
                            card_inner_w - 170, card_pad + 38, 170, LV_TEXT_ALIGN_RIGHT);

    /*
     * Variação menor que antes. O valor continua recebendo verde/vermelho
     * pelo controlador; "em 24 h" é estático e branco.
     */
    view.btc_change_icon = np_label(card, NP_ICON_RISE, NP_FONT_ICON, np_c_text_3(),
                                    card_pad, card_pad + 144, 24, LV_TEXT_ALIGN_LEFT);

    view.btc_change = np_label(card, "--", NP_FONT_MD, np_c_text_3(),
                               card_pad + 28, card_pad + 140, 112, LV_TEXT_ALIGN_LEFT);


    /*
     * Não mostramos "Histórico ainda indisponível". O espaço central fica
     * reservado ao sparkline quando houver amostras reais.
     */
    np_hline(card, card_pad, card_pad + 304, card_inner_w);

    np_metric(card, card_pad, card_pad + 326, 128, "Máx. 24 h", "--", NP_FONT_SM);
    np_metric(card, card_pad + 142, card_pad + 326, 128, "Mín. 24 h", "--", NP_FONT_SM);
    np_metric(card, card_pad + 284, card_pad + 326, 128, "Volume", "--", NP_FONT_SM);    np_dots(view.root, 578, 6, 0);
    return view;
}

lv_obj_t *np_home_create(lv_obj_t *parent)
{
    return np_home_build(parent).root;
}
