#include "weather_asset_service.h"

#include <stdio.h>
#include <string.h>

#include "bsp/esp32_p4_wifi6_touch_lcd_7b.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "lvgl.h"

#include "ui/assets/np_weather_background_assets.h"

#define WEATHER_ASSET_TASK_STACK_BYTES (5U * 1024U)
#define WEATHER_ASSET_TASK_PRIORITY 2U
#define WEATHER_ASSET_WORKER_PERIOD_MS 100U
#define WEATHER_ASSET_SLOT_COUNT 2U
#define WEATHER_ASSET_PATH_MAX 96U
#define WEATHER_ASSET_DIRECTORY "/np2/weather"
/* Os arquivos no SD são RGB565 compactos: 500 px * 2 bytes por linha.
 * LVGL 9 neste firmware, porém, usa stride de draw buffer de 64 bytes. Sem
 * este padding, o decoder aloca e preenche uma segunda imagem inteira quando
 * o card é desenhado. O slot em PSRAM já nasce com o stride correto; a leitura
 * apenas coloca cada linha compacta na sua posição, sem resize ou conversão. */
#define WEATHER_ASSET_FILE_ROW_BYTES ((size_t)NP_WEATHER_BACKGROUND_WIDTH * 2U)
#define WEATHER_ASSET_STRIDE_BYTES \
    (((WEATHER_ASSET_FILE_ROW_BYTES + LV_DRAW_BUF_STRIDE_ALIGN - 1U) / \
      LV_DRAW_BUF_STRIDE_ALIGN) * LV_DRAW_BUF_STRIDE_ALIGN)
#define WEATHER_ASSET_FILE_BYTES \
    (WEATHER_ASSET_FILE_ROW_BYTES * (size_t)NP_WEATHER_BACKGROUND_HEIGHT)
#define WEATHER_ASSET_BUFFER_BYTES \
    (WEATHER_ASSET_STRIDE_BYTES * (size_t)NP_WEATHER_BACKGROUND_HEIGHT)

typedef struct {
    uint8_t *pixels;
    lv_image_dsc_t image;
} weather_asset_slot_t;

static const char *const TAG = "weather_assets";
static portMUX_TYPE s_lock = portMUX_INITIALIZER_UNLOCKED;
static weather_asset_service_status_t s_status = {
    .last_result = ESP_ERR_INVALID_STATE,
};
static weather_asset_slot_t s_slots[WEATHER_ASSET_SLOT_COUNT];
static bool s_started;
static bool s_request_pending;
static bool s_loading;
static bool s_requested_day;
static weather_condition_t s_requested_condition;
static uint8_t s_next_slot;
static bool s_last_attempt_valid;
static bool s_last_attempt_day;
static weather_condition_t s_last_attempt_condition;

static void set_status_result(esp_err_t result)
{
    taskENTER_CRITICAL(&s_lock);
    s_status.last_result = result;
    taskEXIT_CRITICAL(&s_lock);
}

static esp_err_t allocate_slots(void)
{
    for (uint8_t index = 0U; index < WEATHER_ASSET_SLOT_COUNT; ++index) {
        s_slots[index].pixels = heap_caps_aligned_alloc(
            LV_DRAW_BUF_ALIGN, WEATHER_ASSET_BUFFER_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (s_slots[index].pixels == NULL) {
            return ESP_ERR_NO_MEM;
        }
        s_slots[index].image = (lv_image_dsc_t){
            .header = {
                .magic = LV_IMAGE_HEADER_MAGIC,
                .cf = LV_COLOR_FORMAT_RGB565,
                .flags = 0,
                .w = NP_WEATHER_BACKGROUND_WIDTH,
                .h = NP_WEATHER_BACKGROUND_HEIGHT,
                .stride = WEATHER_ASSET_STRIDE_BYTES,
                .reserved_2 = 0,
            },
            .data_size = WEATHER_ASSET_BUFFER_BYTES,
            .data = s_slots[index].pixels,
            .reserved = NULL,
            .reserved_2 = NULL,
        };
    }
    return ESP_OK;
}

static esp_err_t load_requested_asset(bool is_day, weather_condition_t condition, uint8_t slot)
{
    const char *const filename = np_weather_background_asset_file_name(is_day, condition);
    if (filename == NULL || slot >= WEATHER_ASSET_SLOT_COUNT || s_slots[slot].pixels == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    char path[WEATHER_ASSET_PATH_MAX] = {0};
    const int path_length = snprintf(path, sizeof(path), "%s%s/%s", BSP_SD_MOUNT_POINT,
                                     WEATHER_ASSET_DIRECTORY, filename);
    if (path_length < 0 || (size_t)path_length >= sizeof(path)) {
        return ESP_ERR_INVALID_SIZE;
    }

    FILE *const file = fopen(path, "rb");
    if (file == NULL) {
        ESP_LOGW(TAG, "weather background not available: %s", path);
        return ESP_ERR_NOT_FOUND;
    }
    esp_err_t result = ESP_OK;
    if (fseek(file, 0L, SEEK_END) != 0 || ftell(file) != (long)WEATHER_ASSET_FILE_BYTES ||
        fseek(file, 0L, SEEK_SET) != 0) {
        result = ESP_ERR_INVALID_SIZE;
    } else {
        for (uint16_t row = 0U; row < NP_WEATHER_BACKGROUND_HEIGHT; ++row) {
            uint8_t *const row_pixels =
                s_slots[slot].pixels + ((size_t)row * WEATHER_ASSET_STRIDE_BYTES);
            if (fread(row_pixels, 1U, WEATHER_ASSET_FILE_ROW_BYTES, file) !=
                WEATHER_ASSET_FILE_ROW_BYTES) {
                result = ESP_FAIL;
                break;
            }
            memset(row_pixels + WEATHER_ASSET_FILE_ROW_BYTES, 0,
                   WEATHER_ASSET_STRIDE_BYTES - WEATHER_ASSET_FILE_ROW_BYTES);
        }
    }
    (void)fclose(file);
    if (result != ESP_OK) {
        ESP_LOGW(TAG, "invalid weather background: %s (%s)", path, esp_err_to_name(result));
    }
    return result;
}

static esp_err_t verify_asset_catalog(void)
{
    for (uint8_t period = 0U; period < 2U; ++period) {
        for (weather_condition_t condition = WEATHER_CONDITION_CLEAR;
             condition <= WEATHER_CONDITION_VARIABLE; ++condition) {
            const char *const filename = np_weather_background_asset_file_name(period == 0U,
                                                                                condition);
            char path[WEATHER_ASSET_PATH_MAX] = {0};
            const int path_length = snprintf(path, sizeof(path), "%s%s/%s", BSP_SD_MOUNT_POINT,
                                             WEATHER_ASSET_DIRECTORY, filename);
            if (path_length < 0 || (size_t)path_length >= sizeof(path)) {
                return ESP_ERR_INVALID_SIZE;
            }
            FILE *const file = fopen(path, "rb");
            if (file == NULL) {
                ESP_LOGW(TAG, "weather asset catalog incomplete: %s", path);
                return ESP_ERR_NOT_FOUND;
            }
            const bool size_is_valid = fseek(file, 0L, SEEK_END) == 0 &&
                                       ftell(file) == (long)WEATHER_ASSET_FILE_BYTES;
            (void)fclose(file);
            if (!size_is_valid) {
                ESP_LOGW(TAG, "weather asset catalog has invalid size: %s", path);
                return ESP_ERR_INVALID_SIZE;
            }
        }
    }
    return ESP_OK;
}

static void weather_asset_task(void *arg)
{
    (void)arg;
    esp_err_t result = allocate_slots();
    if (result != ESP_OK) {
        ESP_LOGE(TAG, "PSRAM allocation for two weather images failed: %s", esp_err_to_name(result));
        set_status_result(result);
        vTaskDelete(NULL);
        return;
    }

    /* The Waveshare BSP owns the SDMMC pin configuration. Its Kconfig keeps
     * format_if_mount_failed disabled; this service never changes that policy. */
    result = bsp_sdcard_mount();
    const bool mounted = result == ESP_OK ||
                         (result == ESP_ERR_INVALID_STATE && bsp_sdcard != NULL);
    taskENTER_CRITICAL(&s_lock);
    s_status.ready = true;
    s_status.mounted = mounted;
    s_status.last_result = mounted ? ESP_OK : result;
    taskEXIT_CRITICAL(&s_lock);
    if (!mounted) {
        ESP_LOGW(TAG, "microSD unavailable; Home will keep the neutral weather card: %s",
                 esp_err_to_name(result));
    } else {
        result = verify_asset_catalog();
        set_status_result(result);
        if (result == ESP_OK) {
            ESP_LOGI(TAG, "microSD mounted at %s; validated 20 weather assets in %s%s",
                     BSP_SD_MOUNT_POINT, BSP_SD_MOUNT_POINT, WEATHER_ASSET_DIRECTORY);
        } else {
            ESP_LOGW(TAG, "microSD mounted, but weather catalog is unusable: %s",
                     esp_err_to_name(result));
        }
    }

    for (;;) {
        bool pending = false;
        bool is_day = false;
        weather_condition_t condition = WEATHER_CONDITION_VARIABLE;
        taskENTER_CRITICAL(&s_lock);
        if (mounted && s_request_pending) {
            pending = true;
            is_day = s_requested_day;
            condition = s_requested_condition;
            s_request_pending = false;
            s_loading = true;
        }
        taskEXIT_CRITICAL(&s_lock);

        if (pending) {
            const uint8_t slot = s_next_slot;
            result = load_requested_asset(is_day, condition, slot);
            if (result == ESP_OK) {
                ESP_LOGI(TAG, "loaded weather background: %s",
                         np_weather_background_asset_file_name(is_day, condition));
            }
            taskENTER_CRITICAL(&s_lock);
            s_loading = false;
            s_status.pending = s_request_pending;
            s_status.last_result = result;
            s_last_attempt_valid = true;
            s_last_attempt_day = is_day;
            s_last_attempt_condition = condition;
            if (result == ESP_OK) {
                s_status.available = true;
                s_status.is_day = is_day;
                s_status.condition = condition;
                s_status.source = &s_slots[slot].image;
                ++s_status.generation;
                ++s_status.load_count;
                s_next_slot = (uint8_t)((slot + 1U) % WEATHER_ASSET_SLOT_COUNT);
            }
            taskEXIT_CRITICAL(&s_lock);
        }
        vTaskDelay(pdMS_TO_TICKS(WEATHER_ASSET_WORKER_PERIOD_MS));
    }
}

esp_err_t weather_asset_service_start(void)
{
    taskENTER_CRITICAL(&s_lock);
    if (s_started) {
        taskEXIT_CRITICAL(&s_lock);
        return ESP_ERR_INVALID_STATE;
    }
    s_started = true;
    taskEXIT_CRITICAL(&s_lock);

    if (xTaskCreate(weather_asset_task, "np2_weather_sd", WEATHER_ASSET_TASK_STACK_BYTES, NULL,
                    WEATHER_ASSET_TASK_PRIORITY, NULL) != pdPASS) {
        taskENTER_CRITICAL(&s_lock);
        s_started = false;
        taskEXIT_CRITICAL(&s_lock);
        return ESP_ERR_NO_MEM;
    }
    return ESP_OK;
}

esp_err_t weather_asset_service_request(uint8_t hour, uint16_t weather_code)
{
    if (hour > 23U) {
        return ESP_ERR_INVALID_ARG;
    }
    const bool is_day = weather_condition_is_day(hour);
    const weather_condition_t condition = weather_condition_from_code(weather_code);

    taskENTER_CRITICAL(&s_lock);
    if (!s_started) {
        taskEXIT_CRITICAL(&s_lock);
        return ESP_ERR_INVALID_STATE;
    }
    if (s_status.available && s_status.is_day == is_day && s_status.condition == condition &&
        !s_request_pending) {
        taskEXIT_CRITICAL(&s_lock);
        return ESP_OK;
    }
    if (s_loading && s_requested_day == is_day && s_requested_condition == condition) {
        taskEXIT_CRITICAL(&s_lock);
        return ESP_OK;
    }
    if (s_last_attempt_valid && s_last_attempt_day == is_day &&
        s_last_attempt_condition == condition && !s_request_pending) {
        const esp_err_t result = s_status.last_result;
        taskEXIT_CRITICAL(&s_lock);
        return result;
    }
    if (!s_request_pending || s_requested_day != is_day || s_requested_condition != condition) {
        s_requested_day = is_day;
        s_requested_condition = condition;
        s_request_pending = true;
    }
    s_status.pending = true;
    taskEXIT_CRITICAL(&s_lock);
    return ESP_OK;
}

void weather_asset_service_get_status(weather_asset_service_status_t *out_status)
{
    if (out_status == NULL) {
        return;
    }
    taskENTER_CRITICAL(&s_lock);
    *out_status = s_status;
    taskEXIT_CRITICAL(&s_lock);
}
